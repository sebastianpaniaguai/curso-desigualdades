# curso-desigualdades
Plantilla OVA -Medición y monitoreo de desigualdades e inequidades geográficas en salud
